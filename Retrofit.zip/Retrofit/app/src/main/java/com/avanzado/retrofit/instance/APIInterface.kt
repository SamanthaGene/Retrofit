package com.avanzado.retrofit.instance

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import com.avanzado.retrofit.model.ExampleResponse

interface APIInterface {
    @GET("https://stats.nba.com/stats/allstarballotpredictor")
    fun getExampleData(): Call<ExampleResponse>
}