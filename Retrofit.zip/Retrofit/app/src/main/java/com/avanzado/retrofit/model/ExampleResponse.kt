package com.avanzado.retrofit.model

data class ExampleResponse(
    val id: Int,
    val name: String,
    val description: String
)
